import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RuteoRoutingModule } from './ruteo-routing.module';

@NgModule({
  imports: [
    CommonModule,
    RuteoRoutingModule
  ],
  exports:[RuteoRoutingModule],
  declarations: []
})
export class RuteoModule { }
