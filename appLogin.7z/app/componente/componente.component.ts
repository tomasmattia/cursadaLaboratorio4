import { Component, OnInit } from '@angular/core';
import { DataService } from '../servicios/data.service'

@Component({
  selector: 'app-componente',
  templateUrl: './componente.component.html',
  styleUrls: ['./componente.component.css']
})
export class ComponenteComponent implements OnInit {

  constructor(private data:DataService) { }

  // ngOnInit() {
  //   this.data.SinToken().subscribe(data=>{console.log(data)}, err=>{console.log(err)});
  // }
  ngOnInit() {
     this.data.ConToken().subscribe(data=>{console.log(data)}, err=>{console.log(err)});
  }
  
}
