import { Component, OnInit } from '@angular/core';
import { DataService } from '../servicios/data.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
  
export class LoginComponent implements OnInit {
  constructor(private data:DataService) { }
  usuario;
  pass;
  ngOnInit() {
  }
  MostrarCred()
  {
    console.log(this.usuario+' '+this.pass);
    this.GuardarToken();
  }

  GuardarToken()
  {
    this.data.ConToken().subscribe(data=>{localStorage.setItem('token',data['token'])}, err=>{console.log(err)});
  }

  PegarListado()
  {
    this.data.Listado().subscribe(data=>{console.log(data)}, err=>{console.log(err)});
  }
}
