import { Component , Input } from '@angular/core';
// import { Persona } from './persona';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'second-app';
  
  //  unaPersona:Persona;
  //  cantidad:number;
  //  nrSelect=1;
  // listenerListaPersonas(e)
  // {
  //   if(e)
  //   {
  //     this.unaPersona=e;
  //   }
  // }

  // Ecantidad (e)
  // {
  //   if(e)
  //   {
  //     this.cantidad=e;
  //   }
  // }

}

