import { Component, OnInit , OnChanges, OnDestroy, AfterViewInit, Input , Output, EventEmitter } from '@angular/core';
import { Persona } from '../persona';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../servicios/data.service';

@Component({
  selector: 'app-grilla',
  templateUrl: './grilla.component.html',
  styleUrls: ['./grilla.component.css']
})

export class GrillaComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  @Output() cantidad = new EventEmitter<number>();
  arrPersonas: Array<Persona>;

  @Input() set lista(listaP:Array<Persona>)
  {
    if(listaP)
    {
      this.data.ConcatLista(listaP);
    }
  }

  @Input() set Persona(unaPersona:Persona){
    if(unaPersona)
    {
      this.data.AddPersona(unaPersona);
      this.cantidad.emit(this.data.GetLista().length);
    }

    console.log(unaPersona);
    console.log(this.data.GetLista());
    
  }

  public Ir()
  {
    this.router.navigate(['/form']);
  }

  Enviar (e)
  {
    console.log(e);
  }

  constructor(public router:Router,public rs:ActivatedRoute, private data:DataService) {
    console.log(rs.snapshot.params['id']);
    console.log(router);
  }

  ngOnInit() {
    this.arrPersonas = this.data.GetLista();
  }
  ngOnChanges() {
    
  }
  ngOnDestroy() {
    console.log('destroy');
  }
  ngAfterViewInit() {
    console.log('after');
  }
}
