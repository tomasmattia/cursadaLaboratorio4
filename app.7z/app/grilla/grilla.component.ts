import { Component, OnInit , OnChanges, OnDestroy, AfterViewInit, Input , Output, EventEmitter } from '@angular/core';
import { Persona } from '../persona';

@Component({
  selector: 'app-grilla',
  templateUrl: './grilla.component.html',
  styleUrls: ['./grilla.component.css']
})

export class GrillaComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  @Output() cantidad = new EventEmitter<number>();
  private arrPersonas:Array<Persona>;

  @Input() set lista(listaP:Array<Persona>)
  {
    if(listaP)
    {
      this.arrPersonas.concat(listaP);
    }
  }

  @Input() set Persona(unaPersona:Persona){
    if(unaPersona)
    {
      this.arrPersonas.push(unaPersona);
      this.cantidad.emit(this.arrPersonas.length);
    }
    console.log(unaPersona);
    console.log(this.arrPersonas);
    
  }

  Enviar (e)
  {
    console.log(e);
  }

  constructor() {
    this.arrPersonas=new Array<Persona>();
  }

  ngOnInit() {
  }
  ngOnChanges() {
    
  }
  ngOnDestroy() {
    console.log('destroy');
  }
  ngAfterViewInit() {
    console.log('after');
  }
}
