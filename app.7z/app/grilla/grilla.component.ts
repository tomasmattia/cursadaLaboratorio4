import { Component, OnInit , OnChanges, OnDestroy, AfterViewInit, Input , Output, EventEmitter } from '@angular/core';
import { Persona } from '../persona';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-grilla',
  templateUrl: './grilla.component.html',
  styleUrls: ['./grilla.component.css']
})

export class GrillaComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  @Output() cantidad = new EventEmitter<number>();
  private arrPersonas:Array<Persona>;

  @Input() set lista(listaP:Array<Persona>)
  {
    if(listaP)
    {
      this.arrPersonas.concat(listaP);
    }
  }

  @Input() set Persona(unaPersona:Persona){
    if(unaPersona)
    {
      this.arrPersonas.push(unaPersona);
      this.cantidad.emit(this.arrPersonas.length);
    }
    console.log(unaPersona);
    console.log(this.arrPersonas);
    
  }

  public Ir()
  {
    this.router.navigate(['/form']);
  }

  Enviar (e)
  {
    console.log(e);
  }

  constructor(public router:Router,public rs:ActivatedRoute) {
    this.arrPersonas=new Array<Persona>();
    console.log(rs.snapshot.params['id']);
    console.log(router);
  }

  ngOnInit() {
  }
  ngOnChanges() {
    
  }
  ngOnDestroy() {
    console.log('destroy');
  }
  ngAfterViewInit() {
    console.log('after');
  }
}
