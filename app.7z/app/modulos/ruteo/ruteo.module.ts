import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { GrillaComponent } from '../../grilla/grilla.component';
import { FormComponent } from '../../form/form.component';
import { HomeComponent } from '../../home/home.component';
import { ErrorComponent } from '../../error/error.component';

const RUTAS:Routes=[ { path:'',component:HomeComponent }, 
{path:'grilla', component:GrillaComponent}, 
{path:'form', component:FormComponent, data:{title:'formulario'}},
// {path:'**', component:ErrorComponent},
{path:'persona', component:GrillaComponent, data:{title:'Lab 4'},
  children:[
    {path:'cargar',component:FormComponent},
    {path:'listar',component:GrillaComponent,
    children:[
      {path:' ',component:GrillaComponent},
      {path:'mayores',component:GrillaComponent}
      ]
    }]
},
{path:'**', component:ErrorComponent}];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(RUTAS)
  ],
  exports:[RouterModule],
  declarations: []
})
export class RuteoModule { }
