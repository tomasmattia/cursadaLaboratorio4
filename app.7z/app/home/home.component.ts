import { Component, OnInit } from '@angular/core';
import { GrillaComponent } from '../grilla/grilla.component';
import { FormComponent } from '../form/form.component';
import { Persona } from '../persona';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() {
    
   }

  ngOnInit() {

  }
    unaPersona:Persona;
   cantidad:number;
   nrSelect=1;
  listenerListaPersonas(e)
  {
    if(e)
    {
      this.unaPersona=e;
    }
  }

  

  Ecantidad (e)
  {
    if(e)
    {
      this.cantidad=e;
    }
  }

}
