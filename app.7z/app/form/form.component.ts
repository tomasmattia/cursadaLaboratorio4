import { Component, OnInit , OnChanges, OnDestroy, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { Persona } from '../persona';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})

export class FormComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  @Input() unaPersona:Persona;
  @Input() lista:Array<Persona>;
  cantidad:number;
  @Output() listaPersonas = new EventEmitter<Persona>();
  @Input() set Cantidad(cant:number)
  {
    if(cant)
    {
      console.log(cant);
      this.cantidad=cant;
    }
  }
  private msj;
  private msjBoton;
  private nombre;
  private apellido;
  private sueldo;
  private msjBotonPersona;
  Enviar (e)
  {
    console.log(e);
  }
  Crear ()
  {
      this.lista.push(new Persona(this.nombre,this.apellido,this.sueldo));
  }

  Ecantidad (e)
  {
    console.log("Cantidad de personas en lista "+ e);
  }

  CrearPersona ()
  {
      this.unaPersona=new Persona(this.nombre,this.apellido,this.sueldo);
      this.listaPersonas.emit(this.unaPersona);
  }
  constructor() {
    this.lista = new Array<Persona>();  
    this.msj="Ingrese Datos";
    this.msjBoton="Enviar"
    this.nombre="pepe";
    this.msjBotonPersona="Cargar Persona";
   }

  ngOnInit() {
  }
  ngOnChanges() {
    console.log('change');
  }
  ngOnDestroy() {
    console.log('destroy');
  }
  ngAfterViewInit() {
    console.log('after');
  }
}
