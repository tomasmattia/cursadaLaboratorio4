export class Persona {
    private nombre;
    private apellido;
    private sueldo;

    constructor(nombre,apellido,sueldo)
    {
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldo = sueldo;
    }
}
