import { Injectable } from '@angular/core';

import { Persona } from '../persona';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private persona:Persona;
  private lista:Array<Persona> = [];
  
  GetPersona()
  {
    return this.persona;
  }
  SetPersona(otraPersona:Persona)
  {
    this.persona=otraPersona; 
  }

  GetLista()
  {
    return this.lista;
  }
  ConcatLista(listaP:Array<Persona>)
  {
    this.lista=this.lista.concat(listaP);
  }
  AddPersona(unaPersona:Persona)
  {
    console.log(unaPersona);
    this.lista.push(unaPersona);
  }

  constructor() { 
   
  }
}
