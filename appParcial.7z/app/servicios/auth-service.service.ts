import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate{
  
  helper =new JwtHelperService();
  constructor(private router:Router) {
    
   }

  canActivate()
  {
    if(localStorage.getItem('token'))
    {
      return true;
    }
    this.router.navigate(['']);
    return false;
  }
}
