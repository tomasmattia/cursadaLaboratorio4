import { Component, OnInit , OnChanges} from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  datosClientes;
  helper=new JwtHelperService();
  constructor() { 

  }
  
  ngOnInit() {
    this.datosClientes=this.helper.decodeToken(localStorage.getItem('token'));
    console.log(this.datosClientes.datosCliente);
    this.datosClientes=JSON.parse(this.datosClientes.datosCliente);
    console.log(this.datosClientes.name);
  }

  onChanges()
  {
    
  }

}
