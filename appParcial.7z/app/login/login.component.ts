import { Component, OnInit } from '@angular/core';
import { DataService } from '../servicios/data.service';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
  
export class LoginComponent implements OnInit {
  helper=new JwtHelperService();
  constructor(private data:DataService,private router:Router) { }
  name;
  pass;

  datosCliente;
  ngOnInit() {
  }
  MostrarCred()
  {
    this.datosCliente=('{"name":"'+this.name+'","pass":"'+this.pass+'"}');
    this.GuardarToken();
    console.log(this.datosCliente);
    
  }

  GuardarToken()
  {
    this.data.Login(this.datosCliente).subscribe(data=>{localStorage.setItem('token',data['token'])}, err=>{console.log(err)});
    this.router.navigate(['home']);
  }

  IrRegistro()
  {
    this.router.navigate(['']);
  }  

}
