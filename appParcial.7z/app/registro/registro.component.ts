import { Component, OnInit } from '@angular/core';
import { DataService } from '../servicios/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
  
export class RegistroComponent implements OnInit {
  constructor(private data:DataService,private router:Router) { }
  name;
  pass;
  tipoUser;
  datosCliente;
  ngOnInit() {
  }
  MostrarCred()
  {
    this.datosCliente=('{"name":"'+this.name+'","pass":"'+this.pass+'","type":"'+this.tipoUser+'"}');
    console.log(this.datosCliente);
    this.GuardarToken();
  }

  GuardarToken()
  {
    this.data.Registro(this.datosCliente).subscribe(data=>{console.log(data)}, err=>{console.log(err)});
  }

  IrLogin()
  {
    this.router.navigate(['login']);
  }
}
