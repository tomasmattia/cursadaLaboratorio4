<?php
    use \Firebase\JWT\JWT as JWT;

    class Verificadora
    {
        public function AltaRegistro($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $clave=$jsonDes->clave;
            $tipo=$jsonDes->tipo;

            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('INSERT INTO `usuarios`(`correo`,`clave`,`tipo`) VALUES (:correo,:clave,:tipo)');
                
                $sql->execute(array(
                    'correo' => $correo,
                    'clave' => $clave,
                    'tipo' => $tipo,
                    
                ));
            }
            catch(PDOException $e) 
            {
                return $response->withJson((["error"=>$e->getMessage()]));
            }
        }

        public function CargarAuto($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $patente=$jsonDes->patente;
            $marca=$jsonDes->marca;
            $color=$jsonDes->color;
            $kilometros=$jsonDes->kilometros;
            $tipo=$jsonDes->tipo;

            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('INSERT INTO `autos`(`correo`,`patente`,`marca`,`color`,`kilometros`,`tipo`) VALUES (:correo,:patente,:marca,:color,:kilometros,:tipo)');
                
                $sql->execute(array(
                    'correo' => $correo,
                    'patente' => $patente,
                    'marca' => $marca,
                    'color' => $color,
                    'kilometros' => $kilometros,
                    'tipo' => $tipo,
                    
                ));
            }
            catch(PDOException $e) 
            {
                return $response->withJson((["error"=>$e->getMessage()]));
            }
        }

        public function CargarTurno($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $turno=$jsonDes->turno;
            $tipo=$jsonDes->tipo;
            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('INSERT INTO `turnos`(`fecha`,`correo`,`tipo`) VALUES (:fecha,:correo,:tipo)');
                
                $sql->execute(array(
                    'correo' => $correo,
                    'fecha' => $turno,
                    'tipo' => $tipo
                    
                ));
            }
            catch(PDOException $e) 
            {
                return $response->withJson((["error"=>$e->getMessage()]));
            }
        }

        public function VerificarUsuario($request,$response,$next)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $clave=$jsonDes->clave;
            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('SELECT `correo`,`clave` FROM `usuarios` WHERE `correo` = :correo AND `clave` = :clave');
                $sql->bindValue(':correo', $correo);
                $sql->bindValue(':clave', $clave);
                $sql->execute();
                $result = $sql->rowCount();
                if($result)
                { 
                    $response = $next($request, $response);
                }
                else
                {
                    return $response->withJson((["mensaje"=>"Datos de logeo incorrectos"]));
                }
            }
            catch(PDOException $e)
            {
                return "Error!\n" . $e->getMessage();
            }
            return $response;
        }

        public function ValidarToken($request,$response,$next)
        {
            $elToken= $request->getHeader('token');
            try
            {
                $jwtDecode = JWT::decode($elToken[0],'example_key',array('HS256'));
                $response = $next($request, $response);
                return $response;
            }
            catch(Exception $e)
            {
                return $response->withJson((["mensaje"=>"token invalido"]),200);
            }
        }

        public static function TraerEstadistica($request,$response)
        {
            $arrayEmpleados=array();
            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('SELECT * FROM `turnos`');
                $sql->execute();
                while($result = $sql->fetchObject())
                {
                    array_push($arrayEmpleados,$result);
                }
            }
            catch(PDOException $e)
            {
                echo "Error!\n" . $e->getMessage();
            }
            return $arrayEmpleados;
        }

        

        public function AltaEstadistica($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;

            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=tpjuegos;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('INSERT INTO `estadisticas`(`correo`) VALUES (:correo)');
                
                $sql->execute(array(
                    'correo' => $correo,
                ));
            }
            catch(PDOException $e) 
            {
                return $response->withJson((["error"=>$e->getMessage()]));
            }
        }

        public function ModEstadistica($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $juego=$jsonDes->juego;
            $cuanto=$jsonDes->cuanto;
            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=tpjuegos;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('UPDATE `estadisticas` SET '.$juego.'='.$juego.'+'.$cuanto.' WHERE `correo`=:correo');
                
                $sql->execute(array(
                    'correo' => $correo
                ));
            }
            catch(PDOException $e) 
            {
                return $response->withJson((["error"=>$e->getMessage()]));
            }            
        }

        public function EsAdmin($request,$response)
        {
            $json=$request->getParsedBody();
            $jsonDes= json_decode($json['json']);
            $correo=$jsonDes->correo;
            $clave=$jsonDes->clave;
            try
            {
                $usuario='root';
                $pass='';
                $objetoPDO = new PDO('mysql:host=localhost;dbname=parcialAuto;charset=utf8', $usuario, $pass);
                $sql=$objetoPDO->prepare('SELECT `tipo` FROM `usuarios` WHERE `correo` = :correo AND `clave` = :clave');
                $sql->bindValue(':correo', $correo);
                $sql->bindValue(':clave', $clave);
                $sql->execute();
                $result = $sql->rowCount();
                if($result)
                {
                    $objeto=$sql->fetchObject();
                    if ($objeto->tipo ==="Admin") 
                    {
                        return true;
                    }
                }
                return false;
            }
            catch(PDOException $e)
            {
                return false;                
            }
        }

    }
    
?>